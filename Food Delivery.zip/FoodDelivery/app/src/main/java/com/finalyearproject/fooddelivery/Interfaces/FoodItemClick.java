package com.finalyearproject.fooddelivery.Interfaces;

public interface FoodItemClick {
    void onClick(int position);
    void onClick(String type, int position);
}
